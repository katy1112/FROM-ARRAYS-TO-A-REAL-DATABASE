<!DOCTYPE html>
<html>
<head>
    <title>Customer Accounts</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>

<body>

<header>
    <h1>Customer Accounts</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/about') ?>">About</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
    </nav>
</header>

<div class="container">

    <table>

        <thead>
            <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
            </tr>
        </thead>

        <tbody>

            <?php foreach ($customers as $customer): ?>

                <tr>
                    <td><?= $customer['full_name'] ?></td>
                    <td><?= $customer['email'] ?></td>
                    <td><?= $customer['phone'] ?></td>
                </tr>

            <?php endforeach; ?>

        </tbody>

    </table>

</div>

</body>
</html>