<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Accounts</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">
</head>

<body>

<header>
    <h1>POS System</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('about') ?>">About</a>
        <a href="<?= base_url('customers') ?>">Customers</a>
        <a href="<?= base_url('users') ?>">Users</a>
    </nav>
</header>


<div class="container">

    <div class="card">

        <h2>User Accounts</h2>

        <p>
            User account records retrieved from the MySQL database.
        </p>

    </div>


    <table>

        <thead>
            <tr>
                <th>Username</th>
                <th>Full Name</th>
                <th>Created At</th>
            </tr>
        </thead>

        <tbody>

            <?php foreach ($users as $user): ?>

                <tr>
                    <td>
                        <span class="badge">
                            <?= esc($user['username']) ?>
                        </span>
                    </td>

                    <td>
                        <?= esc($user['full_name']) ?>
                    </td>

                    <td>
                        <?= esc($user['created_at']) ?>
                    </td>
                </tr>

            <?php endforeach; ?>

        </tbody>

    </table>

</div>

</body>
</html>